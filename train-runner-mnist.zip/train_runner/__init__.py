from .train_mnist import train


def run():
	train(10)
